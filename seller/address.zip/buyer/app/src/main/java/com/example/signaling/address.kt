package com.example.signaling

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class address : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address)
        var add = findViewById<EditText>(R.id.address)
        var cont = findViewById<Button>(R.id.cont)

    }
}