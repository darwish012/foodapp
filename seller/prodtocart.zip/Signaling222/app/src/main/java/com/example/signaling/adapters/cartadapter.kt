package com.example.signaling.adapters

import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.signaling.R
import com.example.signaling.product.productsstr
import com.google.firebase.auth.FirebaseAuth

class cartadapter (var context: Context, var arrayList: ArrayList<productsstr>): RecyclerView.Adapter<cartadapter.ItemHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        val itemHolder=
            LayoutInflater.from(parent.context).inflate(R.layout.grid_layout_cartitems,parent,false)
        return ItemHolder(itemHolder)

    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {

        var productsstr: productsstr =arrayList.get(position)

        holder.name.text =productsstr.productname
        holder.price.text=productsstr.productprice
        holder.quantity.text=productsstr.productquan
        var pq: String= holder.quantity.text as String
        var pp:String=holder.price.text as String
        var tp:Int=pp.toInt()*pq.toInt()
        holder.total_price.text="Total:"+tp.toString()

        holder.plus.setOnClickListener {
            var g: String= holder.quantity.text as String
            if(g.toInt()<=productsstr.productquan!!.toInt()){
                holder.quantity.text= (g.toIntOrNull()?.plus(1))!!.toString()
                var pq: String= holder.quantity.text as String
                var pp:String=holder.price.text as String
                var tp:Int=pp.toInt()*pq.toInt()
                holder.total_price.text="Total:"+tp.toString()


            }


        }
        holder.minus.setOnClickListener {
            var g: String= holder.quantity.text as String
            if(g.toInt()>0){
                holder.quantity.text= (g.toIntOrNull()?.minus(1))!!.toString()
                var pq: String= holder.quantity.text as String
                var pp:String=holder.price.text as String
                var tp:Int=pp.toInt()*pq.toInt()
                holder.total_price.text= "Total:" +tp.toString()

            }
        }
    }
    class ItemHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var icons =itemView.findViewById<ImageView>(R.id.icon_image)
        var name =itemView.findViewById<TextView>(R.id.product_name)
        var price =itemView.findViewById<TextView>(R.id.product_price)
        var quantity=itemView.findViewById<TextView>(R.id.product_quan)
        var plus =itemView.findViewById<ImageView>(R.id.cartaddbutton)
        var minus =itemView.findViewById<ImageView>(R.id.cartminusbutton)
        var total_price =itemView.findViewById<TextView>(R.id.total_product_price)


    }
    private fun imgview(x: String) {

    }
}