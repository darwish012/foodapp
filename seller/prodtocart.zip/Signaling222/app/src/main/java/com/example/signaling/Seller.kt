package com.example.signaling

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.example.signaling.adapters.productAdapter
import com.example.signaling.product.productsstr
import com.google.android.material.tabs.TabLayout

class Seller : AppCompatActivity() {

    private lateinit var pTabs: TabLayout
    private lateinit var ptitle: TextView
    private lateinit var pViewPager: ViewPager
    private lateinit var pagerAdapters: PagerAdapters


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seller)



      //  startActivity(Intent(this, Seller::class.java))
        val object1 = intent.getSerializableExtra("object1") as shops
        val bundle = Bundle()
        bundle.putSerializable("key", object1)
val fragment =ProductFragment()
        fragment.arguments=bundle
        pTabs = findViewById(R.id.tabs)

        pViewPager = findViewById(R.id.myPagerView)
        pagerAdapters = PagerAdapters(supportFragmentManager)

        pagerAdapters.addFragment(fragment,"Products")
        pagerAdapters.addFragment(CartFragment(),"Cart")


        pViewPager.adapter = pagerAdapters

        pTabs.setupWithViewPager(pViewPager)

    }

}