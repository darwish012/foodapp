package com.example.signaling

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.signaling.adapters.cartadapter
import com.example.signaling.adapters.productAdapter
import com.example.signaling.product.productsstr
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.io.Serializable


class CartFragment : Fragment(),Serializable {
    public var cart:ArrayList<productsstr>?=null
    private var recyclerView: RecyclerView?=null
    private var gridLayoutManager: GridLayoutManager?=null
    private var cartAdapter: cartadapter?=null
    private lateinit var mAuth: FirebaseAuth

    val childrenList = arrayListOf<productsstr>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cart, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mAuth = FirebaseAuth.getInstance()
        val user = mAuth.currentUser
        val uid = user?.uid
        val parentNodeRef: DatabaseReference = FirebaseDatabase.getInstance().reference.child("buyers").child(uid!!).child("cart")
        recyclerView = view.findViewById(R.id.my_rv3)
        gridLayoutManager = GridLayoutManager(requireActivity().application, 1, LinearLayoutManager.VERTICAL, false)
        recyclerView?.layoutManager = gridLayoutManager
        recyclerView?.setHasFixedSize(true)



        cart= ArrayList()

        cart=setDataInList()
        cartAdapter= cartadapter(requireContext(), childrenList!!)
        recyclerView?.adapter=cartAdapter

        parentNodeRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Get the number of children
                var i =0
                childrenList.clear()
                for (item in snapshot.children){
                    var x =  item.getValue(productsstr::class.java)
                    item.getValue(productsstr::class.java)?.let { childrenList.add(it) }
                    childrenList.get(i).pic= item.child("pic").getValue(String::class.java).toString()
                    i=i+1
                    if (x != null) {
                        Log.d("product class", x.productname.toString())
                    }
                }
                cartAdapter!!.notifyDataSetChanged()

                //    childcount = snapshot.childrenCount.toInt()

                //  Log.d("YourActivity", "Number of Children: $numberOfChildren")
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle errors if there are any
            }
        })


        /*
          parentNodeRef.addChildEventListener(object : ChildEventListener {
              override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                  // A new child is added
                  val product = snapshot.getValue(productsstr::class.java)
                  if(isalredyin(childrenList,product)==true){
                      for(item in childrenList){
                          if(item.productname.equals(product!!.productname)){
                            childrenList.remove(item)
  val x =5

                            childrenList.add(product)

                          }

                      }

                  }
                 else{
                  product?.let {
                      childrenList.add(it)
                  }}

                  cartAdapter!!.notifyDataSetChanged()
                  // Now, productList contains the updated list
                  // You can perform further actions with the updated list here
              }

              override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                  // An existing child is modified
                  // You can update the productList accordingly
                //  val product = snapshot.getValue(productsstr::class.java)

             //  var product1 = snapshot.getValue(productsstr::class.java)


              }

              override fun onChildRemoved(snapshot: DataSnapshot) {
                  // An existing child is removed
                  // You can update the productList accordingly
              }

              override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                  // A child is moved (not commonly used)
              }

              override fun onCancelled(error: DatabaseError) {
                  // Handle the error
              }
          })*/
        //  val object1 = requireActivity().application.getSerializableExtra("object1") as shops




    }
    private fun setDataInList():ArrayList<productsstr>{
        var items:ArrayList<productsstr> =ArrayList()

        items.add(productsstr(R.drawable.sinacola,"sinacola","2","100"))
        items.add(productsstr(R.drawable.sinacola,"sinapepsi","4","100"))
        items.add(productsstr(R.drawable.sinacola,"sinapepsi","4","100"))
        items.add(productsstr(R.drawable.sinacola,"sinapepsi","5","100"))
        items.add(productsstr(R.drawable.sinacola,"sinapepsi","4","100"))
        items.add(productsstr(R.drawable.sinacola,"zengi","400","100"))
        items.add(productsstr(R.drawable.sinacola,"zengi","400","100"))
        items.add(productsstr(R.drawable.sinacola,"yahooody","400","100"))
        return items

    }

    private fun isalredyin(childrenList: ArrayList<productsstr>, product: productsstr?): Boolean{

        if(childrenList.isEmpty()){
            return false
        }
        else{

            for(item in childrenList){
                if(item.productname.equals(product!!.productname)){
                    return true
                }

            }
            return false
        }

    }
}